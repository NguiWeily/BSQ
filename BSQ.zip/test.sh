./bsq test00 test01 test02 test03 test04 test05
