# Run the tab_generator
perl tab_generator.pl 10 11 5

# WHERE
#	10: number of rows
#	11: number of columns
#	 5: density of obstacles
